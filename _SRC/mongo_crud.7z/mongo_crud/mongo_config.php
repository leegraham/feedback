<?php
$conn = new Mongo();
$db = $conn->test;
$collection = $db->people;
?>